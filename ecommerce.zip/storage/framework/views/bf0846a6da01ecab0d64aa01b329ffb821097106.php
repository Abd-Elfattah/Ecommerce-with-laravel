<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-lg-12">
            <div style="margin-top:20px">
				<div>
					
					<h5>
						<p style="font-size: 16px;font-weight: bold">
							<span>Client Name :</span>
							<?php echo e(App\User::find($payment->user_id)->firstname . " " . 
							App\User::find($payment->user_id)->lastname); ?>

						</p>
						<p style="font-weight: bold">
							<span>Shipping To : 
								<?php $address = App\Address::find($payment->address_id); ?>
								<span><?php echo e($address->city); ?></span>
								<span> ,<?php echo e($address->area); ?></span>
								<p>Mobile : <?php echo e($address->mobile); ?></p>
							</span>
						</p>
						<span>Date : <?php echo e($payment->created_at->toDayDateTimeString()); ?></span> 
						<span style="margin-left: 15%">Status : 
							<?php if($payment->is_delivered == 0): ?>
								<?php echo e("Processing"); ?><span style="margin-left: 8px;font-size: 18px;color:#a94442;"><i class="fa fa-times-circle-o"></i></span>
							<?php else: ?>
								<?php echo e("Delivered"); ?><span style="margin-left: 6px;font-size: 18px;color:#3c763d;"><i class="fa fa-check-circle-o"></i></span>
							<?php endif; ?>
						</span>
						<?php $address = App\Address::find($payment->address_id); ?>
						<p>Address: <span><?php echo e($address->city . ", ".$address->area); ?></span></p>
					</h5>
					
				</div>
				<table class="table table-bordered" style="width:90%;">
					<tbody>
						<tr class="techSpecRow">
							<td class="techSpecTD1">Order Num</td>
							<td class="techSpecTD2">Number of Products</td>
							<td class="techSpecTD2">Totall-Price (EGP)</td>
							<td class="techSpecTD2">totall-Discount (EGP)</td>
							<td class="techSpecTD2">After-Discount (EGP)</td>
						</tr>
						<tr>
							<td class="techSpecTD1"><?php echo e($payment->id); ?></td>
							<td class="techSpecTD1"><?php echo e($payment->orders->count()); ?></td>
							<td class="techSpecTD1"><?php echo e($payment->totall_before_discount); ?></td>
							<td class="techSpecTD1"><?php echo e($payment->totall_discount); ?></td>
							<td class="techSpecTD1"><?php echo e($payment->totall_price); ?></td>
						</tr>
						
					</tbody>
				</table>
				<p style="font-weight: bold;margin-bottom: 0px">More Details :</p>
				<table class="table table-bordered" style="width:90%">
					<tbody>
						<tr class="techSpecRow">
							<td class="techSpecTD1">Product</td>
							<td class="techSpecTD2">Color</td>
							<td class="techSpecTD2">Quantity</td>
							<td class="techSpecTD2">Before-discount (EGP)</td>
							<td class="techSpecTD2">Discount (EGP)</td>
							<td class="techSpecTD2">Price (EGP)</td>
						</tr>
						<?php $__currentLoopData = $payment->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						<?php $product = App\Product::findOrFail($order->product_id);  ?>
						<?php $color = App\Color::findOrFail($order->color_id) ;?>

						<tr class="techSpecRow">
							<td class="techSpecTD1"><?php echo e($product->name); ?></td>
							<td class="techSpecTD2"><?php echo e($color->name); ?></td>
							<td class="techSpecTD2"><?php echo e($order->quantity); ?></td>
							<td class="techSpecTD2">
								<?php if($order->quantity == 1): ?>
									<?php echo e($order->price_before_discount); ?>

								<?php else: ?>
									<?php echo e($order->price_before_discount*$order->quantity . 
										" (" . $order->price_before_discount . " For 1)"); ?>

								<?php endif; ?>
							</td>
							<td class="techSpecTD2">
								<?php if($order->quantity == 1): ?>
									<?php echo e($order->discount); ?>

								<?php else: ?>
									<?php if($order->discount != 0): ?>
										<?php echo e($order->discount*$order->quantity . 
											" (" . $order->discount . " For 1)"); ?>

									<?php elseif($order->discount == 0): ?>
										<?php echo e($order->discount); ?>

									<?php endif; ?>
								<?php endif; ?>
							</td>
							<td class="techSpecTD2">
								<?php if($order->quantity == 1): ?>
									<?php echo e($order->price); ?>

								<?php else: ?>
									<?php echo e($order->price*$order->quantity . 
										" (" . $order->price . " For 1)"); ?>

								<?php endif; ?>
							</td>
							
						</tr>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

						

						
					</tbody>
				</table>
			</div>
		</div>

        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>