<?php $__env->startSection('content'); ?>

    <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header col-lg-6 col-lg-offset-3" style="padding-left:0">
                            Create Product
                            
                        </h1>
                        


                    </div>
                </div>
    <!-- /.row -->


    <div class="row">
        <div class="col-lg-6 col-lg-offset-3">
            <?php echo Form::open(['method'=>'POST' , 'action'=>['ProductController@secondStore',$product->id,$sub->id]]); ?>


                <div class="form-group" style="width:60%">
                    <?php echo Form::label('color_id','Color :'); ?>

                    <?php echo Form::select('color_id' , $colors , null , ['class'=>'form-control']); ?>

                </div>


                <div class="form-group" style="width:60%">
                    <?php echo Form::label('quantity','Quantity :'); ?>

                    <?php echo Form::text('quantity' , null , ['class'=>'form-control']); ?>

                </div>
                
                <?php $i=1; ?>
                <?php $__currentLoopData = $sub->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <div class="form-group" style="width:60%">
                       <label for="value<?php echo e($i); ?>"><?php echo e($option->name); ?></label>
                       <input type="text" name="value<?php echo e($i); ?>" id="value<?php echo e($i); ?>" class="form-control">
                    </div>
                <?php $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                


                
                <div class="form-group">
                    <?php echo Form::submit('Continue' , ['class' => 'btn btn-primary']); ?>

                    <span class="pull-right">2/3</span>
                </div>
            <?php echo Form::close(); ?>

        </div>
    </div>





<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>