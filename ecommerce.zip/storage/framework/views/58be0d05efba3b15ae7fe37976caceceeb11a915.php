<?php $__env->startSection('styles'); ?>
	  <link rel="stylesheet" href="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.css">
	<style type="text/css">
		.discount{
			padding: 10px 14px;
			opacity:0.95;
		}

		.product-cart, .product-except{
			margin-top:-35px;
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


	<div class="span9">
    <ul class="breadcrumb">
    <li><a href="<?php echo e(url('/Eco-home')); ?>">Home</a> <span class="divider">/</span></li>
    <li><a href="<?php echo url('Eco-home/sub-category',$product->brand->subcategory->id); ?>"><?php echo e($product->brand->subcategory->name); ?></a> <span class="divider">/</span></li>
    <li class="active">product Details</li>
    </ul>

    
    
	<div class="row">

			<div class="span4">
				<div class="slider">
    	
	    		<?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				    <div><img src="<?php echo e(asset($photo->path)); ?>" style="height:300px"></div>
	            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</div>
			</div>	  
			
			<div class="span5">
				<h3><?php echo e($product->name . " - " . $color->name . " color"); ?> 
				<?php if( ($quantity = $color_product->quantity) >0 && !$product->offer_price == 0): ?>
				<span class="discount">
					<?php echo e(floor(100 - ($product->offer_price/$product->price)*100 )); ?>% off
				</span>
				<?php endif; ?>
				</h3>
				<?php if( $quantity > 0): ?>
					<hr class="soft"/>
				<?php endif; ?>
				
				  <div style="margin-bottom:30px">
					<label class="control-label" style="width:300px">
						<?php if($product->offer_price == 0 && $quantity > 0): ?>
							<span class="price"><?php echo e($product->price); ?> EGP</span>
							
						<?php elseif($quantity > 0): ?>
							<span class="price" style="font-size:19px;font-weight:bold"><?php echo e($product->offer_price); ?> EGP</span>
							<span class="before-discount" style="margin-left:15px"><?php echo e($product->price); ?> EGP</span>
						<?php endif; ?>
					</label>


					<div class="controls">
						<input type="hidden" class="product-id" value="<?php echo e($product->id); ?>">
						<input type="hidden" class="color-id" value="<?php echo e($color->id); ?>">


				<?php if(Session::has('cart') &&  Session::get('cart')->totQty > 0 && $quantity > 0 ): ?>
					<?php if(array_key_exists($color_product->id , Session::get('cart')->items)): ?>
						<a class="btn btn-large btn-primary pull-right product-cart" href="<?php echo e(route('product.removeFromCart' ,['product_id'=>$product->id ,'color_id'=>$color->id])); ?>"> Remove From <i class=" icon-shopping-cart"></i></a>
					<?php elseif( $quantity > 0): ?>
						<a class="btn btn-large pull-right product-cart" href="<?php echo e(route('product.addToCart' ,['product_id'=>$product->id ,'color_id'=>$color->id])); ?>"> Add to cart <i class=" icon-shopping-cart"></i></a>
					<?php endif; ?>

				<?php elseif( $quantity > 0): ?>
					<a class="btn btn-large pull-right product-cart" href="<?php echo e(route('product.addToCart' ,['product_id'=>$product->id ,'color_id'=>$color->id])); ?>"> Add to cart <i class=" icon-shopping-cart"></i></a>
				<?php endif; ?>
					</div>



				  </div>
				
				
					<hr class="soft"/>


				<?php if( $quantity > 10): ?>
					<h4><?php echo e($color_product->quantity); ?> items in stock</h4>
				<?php elseif($quantity <= 10 && $quantity > 0): ?>
					<h4 style="color:#b94a48">only <?php echo e($color_product->quantity); ?> items in stock</h4>
				<?php elseif($quantity == 0): ?>
					<h3 style="color:#b94a48">Out Of Stock</h3>
				<?php endif; ?>


				  <div style="margin-top:6px">
					<h4>Color : <?php echo e($color->name); ?></h4>
					<?php if(count($other_colors) > 0): ?>
					<h5 style="color:#006DCC">Other Colors :
						<?php $__currentLoopData = $other_colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
							<?php if($color == $other_colors->first()): ?>
								<a href="<?php echo e(route('product.color',[$product->id , $color->id])); ?>"><?php echo e($color->name); ?></a>
							<?php else: ?>
								<span style="color:black"> , </span><a href="<?php echo e(route('product.color',[$product->id , $color->id])); ?>"><?php echo e($color->name); ?></a>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					</h5>
					<?php endif; ?>
				  </div>
			<hr class="soft"/>
				
				<a class="btn btn-small pull-right" href="#detail">More Details</a>
				<br class="clr"/>
			<a href="#" name="detail"></a>

			<?php if( $quantity == 0): ?>
				<hr class="soft clr" style="margin-top: 100px" />
			<?php else: ?>
				<hr class="soft clr" style="margin-top: 60px" />
			<?php endif; ?>

			


			</div>
			
			<div class="span9">
            <ul id="productDetail" class="nav nav-tabs">
              <li class="active"><a href="#home" data-toggle="tab">Product Details</a></li>
              <!-- <li><a href="#profile" data-toggle="tab">Related Products</a></li> -->
            </ul>
            <div id="myTabContent" class="tab-content">
              <div class="tab-pane fade active in" id="home">
			  <h4>Product Information</h4>
                <table class="table table-bordered" style="width: 60%">
				<tbody>
				<tr class="techSpecRow"><th colspan="2">Product Details</th></tr>
				<tr class="techSpecRow"><td class="techSpecTD1" style="font-weight: bold">Brand </td><td class="techSpecTD2"><?php echo e($product->brand->name); ?></td></tr>

				<?php $__currentLoopData = $product->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					<tr class="techSpecRow"><td class="techSpecTD1" style="font-weight: bold"><?php echo e($value->option->name); ?> </td><td class="techSpecTD2"><?php echo e($value->name); ?></td></tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

				
				
				</tbody>
				</table>
				
				<h5>Description</h5>
				<p>
				<?php echo e($product->description); ?>

				</p>


              </div>
		
				<br class="clr">
			</div>
		
		</div>
	</div>

</div>

<?php $__env->stopSection(); ?>
		


<?php $__env->startSection('scripts'); ?>
	
  		<script src="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.min.js"></script>
		
		<script type="text/javascript">
				$(document).ready(function(){
		      	
	     	 		$('.slider').bxSlider();
					
				});


		</script>

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>