<?php $__env->startSection('content'); ?>
<div class="span9">
	<?php echo Form::open(['method'=>'GET' , 'action'=>'FrontController@cats']); ?>

	
	<div class="form-group">
		<?php echo Form::label('search','Flickr Search'); ?>

		<?php echo Form::text('search' , null , ['class'=>'form-control' , 'id'=>'search']); ?>

	</div>
	<div class="form-group">
		<?php echo Form::submit('Search' , ['class' => 'btn btn-primary']); ?>

	</div>
	<?php echo Form::close(); ?>

</div>
<div class="content span9">
	
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript">
		$(document).ready(function(){

			$('form').submit(function(evt){
				evt.preventDefault();
				var search = $(this).find('#search').val();

				var flickrApi = "https://api.flickr.com/services/feeds/photos_public.gne?jsoncallback=?";
				var ApiData = {
					tags:search,
					format:'json'
				};
				$.getJSON(flickrApi,ApiData,displayResult); // ----- AJAX -- API ---

				function displayResult(response){
					var content = '';
					$.each(response.items,function(index,value){
						content+='<div class="span3">';
						content+='<a href="'+ value.link +'">';
						content+='<img src="'+ value.media.m +'">';
						content+='</a></div>';
					});
					$('.content').html(content);
				}


				
			});

		

			// $('form').submit(function(evt){
			// 	evt.preventDefault();
			// 	var formData = $('form').serialize();
			// 	var link = "<?php echo e(route('newCat')); ?>";
			// 	$.post(link,formData,function(){
			// 		allCats()
			// 	});
			// });
			// allCats();


			// function allCats(){
			// 	var path = "<?php echo e(route('ajax.cats')); ?>";
			// 	var content = '';
			// 	$.ajax(path,{
			// 		type:'GET',
			// 		success:function(data){
			// 			$.each(data,function(index,value){
			// 				content+='<p>'+ value.name +'</p>';
			// 			}); // end for each

			// 			$('.content').html(content);
			// 		}
			// 	});
			// }


		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>