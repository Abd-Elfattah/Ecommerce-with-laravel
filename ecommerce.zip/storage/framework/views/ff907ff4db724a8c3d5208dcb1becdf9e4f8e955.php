<?php $__env->startSection('styles'); ?>

	<style type="text/css">
		.before-discount{
			
			margin-top: -85px;
			margin-left:110px;
			height: 55px;
		}
		.discount{
			opacity:0.9;
		}
	</style>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
	<div class="span9">
    <ul class="breadcrumb">
		<li><a href="<?php echo e(route('homePage')); ?>">Home</a> <span class="divider">/</span></li>
		<li class="active">Search</li> 
		
    </ul>
	<h3>Search Results<small class="pull-right" style="margin-top:10px">
	<?php if($count > 0): ?>
		<?php echo e($count); ?>	
	<?php else: ?> <?php echo e("No"); ?>


	<?php endif; ?>
	products Found </small></h3>	

	<?php if($count == 0): ?>
	<div class="span9">
		<h3>No Rresults Found</h3>
	</div>
	<?php endif; ?>
	



<div class="tab-content">
	
	<div class="tab-pane  active" id="blockView">
		<ul class="thumbnails">

		<?php if($products): ?>
			<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<?php $__currentLoopData = $product->colors()->withPivot('id')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					<?php if( $color->pivot->quantity == 0 ): ?>	
						<?php continue ?>
					<?php elseif( $color->pivot->quantity > 0 ): ?>
						<li class="span3">
							
						  <div class="thumbnail">
							<a href="<?php echo e(route('product.color' , ['product_id' => $product->id , 'color_id' =>$color->id])); ?>">
							<img class="product-image" src="<?php echo e(asset($color->photos()->where('product_id',$product->id)->first()->path)); ?>" alt=""/>
							</a>
							<div class="caption">
							  <h5 class="product-name" style="margin-bottom: 30px;"><a  href="<?php echo e(route('product.color' , ['product_id' => $product->id , 'color_id' =>$color->id])); ?>"><?php echo e($product->name); ?></a></h5>



						<!-- if offer price found -->
						<?php if($product->offer_price != 0): ?>								  
						<!-- if offer price found -->
									  	<h4 style="text-align:center"><input type="hidden" class="product-id" value="<?php echo e($product->id); ?>">

									
							
							<?php if($color_product=$color->pivot): ?>
								<?php if( Session::has('cart') && Session::get('cart')->totQty > 0 ): ?>
									<?php if(array_key_exists($color_product->id , Session::get('cart')->items)): ?>
									
										<a style="font-weight:bold"  class="btn btn-danger product-cart" href="<?php echo e(route('product.removeFromCart' ,['product_id'=>$product->id ,'color_id'=>$color->id])); ?>">Remove <i class="icon-shopping-cart"></i>
										   		</a>
									<?php else: ?>
										<a style="font-weight:bold"  class="btn product-cart" href="<?php echo e(route('product.addToCart' ,['product_id'=>$product->id ,'color_id'=>$color->id])); ?>">Add To <i class="icon-shopping-cart"></i>
										   		</a>
									<?php endif; ?>

								<?php else: ?>

										<a style="font-weight:bold"  class="btn product-cart" href="<?php echo e(route('product.addToCart' ,['product_id'=>$product->id ,'color_id'=>$color->id])); ?>">Add To <i class="icon-shopping-cart"></i>
										   		</a>
								<?php endif; ?>
							<?php endif; ?>

							


										   <!-- if offer price found -->
										   	<span class="price"><?php echo e($product->offer_price); ?> EGP</span>
										   <!-- if offer price found -->

										   	</h4>
										   	<span class="discount" style="position:relative;top:-310px;left:-14px;">
												<?php echo e(floor((100-(($product->offer_price/$product->price)*100)) )); ?>% off
											</span>
										   	<p class="before-discount">
													<?php echo e($product->price); ?> EGP
											</p>
						<?php endif; ?>
						<!-- if offer price found -->



						<!-- if No offer price found -->
						<?php if($product->offer_price == 0): ?>
						  
					   		 <h4 style="text-align:center">
						
							<?php if($color_product=$color->pivot): ?>
								<?php if(Session::has('cart') && Session::get('cart')->totQty > 0 ): ?>
									<?php if(array_key_exists($color_product->id , Session::get('cart')->items)): ?>
									
										<a style="font-weight:bold"  class="btn btn-danger product-cart" href="<?php echo e(route('product.removeFromCart' ,['product_id'=>$product->id ,'color_id'=>$color->id])); ?>">Remove <i class="icon-shopping-cart"></i>
										   		</a>
									<?php else: ?>
										<a style="font-weight:bold"  class="btn product-cart" href="<?php echo e(route('product.addToCart' ,['product_id'=>$product->id ,'color_id'=>$color->id])); ?>">Add To <i class="icon-shopping-cart"></i>
										   		</a>
									<?php endif; ?>

								<?php else: ?>

										<a style="font-weight:bold"  class="btn product-cart" href="<?php echo e(route('product.addToCart' ,['product_id'=>$product->id ,'color_id'=>$color->id])); ?>">Add To <i class="icon-shopping-cart"></i>
										   		</a>
								<?php endif; ?>
							<?php endif; ?>

							
								   
						   	<span class="price"><?php echo e($product->price); ?> EGP</span>				
						   	</h4>
						   	<span class="discount" style="position:relative;top:-310px;left:-14px;opacity:0">
								0% off
							</span>
						   	<p class="before-discount" style="opacity:0">
									0 EGP
							</p>
						<?php endif; ?>
						<!-- if No offer price found -->

							   
							</div>
						  </div>
						</li>
						<?php break ?>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		<?php endif; ?>
			
		  </ul>


		<br class="clr"/>
	</div>
</div>

	
	


<br class="clr"/>


</div>

<?php $__env->stopSection(); ?>





<?php $__env->startSection('scripts'); ?>
		
		<script type="text/javascript">
	
				

				$(document).ready(function(){
				
					$('#sortBy').on('change' , function(){
						if( $(this).val() == 'brands'){
							
							$('#brands').show();
							window.stop();
						}
					});					

				});

			

		</script>

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>