<?php $__env->startSection('content'); ?>

	<!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header col-lg-12" style="padding-left:0">
                             Orders

                            <a href="<?php echo e(route('DeliveredPayments')); ?>" class="btn btn-info" style=" margin-left:25px">Delivered Oreders</a>
                            <a href="<?php echo e(route('ProcessingPayments')); ?>" class="btn btn-primary">Processing Orders</a>
                        </h1>

                        


                        <?php if(Session::has('createUser')): ?>
                            <ol class="breadcrumb" style="clear:both">
                                <li class="active">
                                    <i class="fa fa-user"></i> 
                                    <span class="text-success"><?php echo e(session('createUser')); ?></span>
                                </li>
                            </ol>

                        <?php endif; ?>



                        <?php if(Session::has('deleteUser')): ?>
                            <ol class="breadcrumb" style="clear:both">
                                <li class="active">
                                    <i class="fa fa-user"></i> 
                                    <span class="text-danger"><?php echo e(session('deleteUser')); ?></span>
                                </li>
                            </ol>

                        <?php endif; ?>
                        
                    </div>
                </div>
    <!-- /.row -->



    <div class="row">
        <div class="col-lg-12">
            <table class="table">
                <thead>
                  <tr>
                    
                    <th>Order Num</th>
                    <th>User</th>
                    <th>Date</th>
                    <th>Totall Price</th>
                    <th>Discount</th>
                    <th>After Disc</th>
                    <th>Status</th>
                    <th>Deliver</th>
                    <th>Details</th>
                  </tr>
                </thead>
                <tbody>
                <?php if($payments): ?>
                    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                      <tr>
                        
                        <td><?php echo e($payment->id); ?></td>
                        <td><?php echo e(App\User::find($payment->user_id)->firstname . " " .App\User::find($payment->user_id)->lastname); ?></td>
                        <td><?php echo e($payment->created_at->diffForHumans()); ?></td>
                        <td><?php echo e($payment->totall_before_discount); ?></td>
                        <td><?php echo e($payment->totall_discount); ?></td>
                        
                        <td><?php echo e($payment->totall_price); ?></td>
                        <td><?php echo e($payment->is_delivered == 1 ? "Delivered" : "Processing"); ?></td>
                        <td>
                        	<?php if($payment->is_delivered == 1): ?>
                        		<?php echo e(" ---------------"); ?>

                        	<?php else: ?>
                        		<a href="<?php echo e(route('payments.deliver' , $payment->id)); ?>">Deliver now</a>
                        	<?php endif; ?>
                        </td>
                        <td><a href="<?php echo e(route('orderDetails',$payment->id)); ?>">Details</a></td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>



    <!-- Pagination -->
    <div class="pagination" style="margin-left: 450px">
    		
    		<?php echo e($payments->render()); ?>


    </div>


    


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>