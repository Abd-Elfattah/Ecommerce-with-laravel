<?php $__env->startSection('styles'); ?>
	
	<style type="text/css">
		.before-discount{
			
			margin-top: -85px;
			margin-left:110px;
			height: 55px;
		}
		.discount{
			opacity:0.9;
		}
	</style>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
	<div class="span9">
    <ul class="breadcrumb">
		<li><a href="<?php echo e(route('homePage')); ?>">Home</a> <span class="divider">/</span></li>
		<li class="active"><?php echo e($sub->name); ?></li> 
		
    </ul>
	<h3><?php echo e($sub->name); ?> Products<small class="pull-right" style="margin-top:10px">
	<?php if($count > 0): ?>
		<?php echo e($count); ?>	
	<?php else: ?> <?php echo e("No"); ?>


	<?php endif; ?>
	products are available </small></h3>	
	<hr class="soft"/>

	<?php if($count == 0): ?>
	<div class="span9">
		<h3>Empty Category</h3>
	</div>
	<?php endif; ?>
	


	<?php if($count > 0): ?>
	<form class="form-horizontal span9">
		<div class="control-group">
		  <label class="control-label alignL" style="font-weight: bold">Sort By </label>
			<select id="sortBy" style="width: 170px" onchange="location = this.value;">
			<?php if(!$sort_type): ?>
              <option selected disabled>Sort By</option>
            <?php endif; ?>

            <?php if($sort_type == 'low'): ?>
              <option value="<?php echo e(route('sortBy.priceLowestFirst',['id'=>$sub->id,'current_page'=>1])); ?>" selected>Price Lowest first</option>
            <?php else: ?>
              <option value="<?php echo e(route('sortBy.priceLowestFirst' , ['id'=>$sub->id,'current_page'=>1])); ?>">Price Lowest first</option>
            <?php endif; ?>

            	
            <?php if($sort_type == 'high' ): ?>
              <option value="<?php echo e(route('sortBy.priceHighestFirst' ,['id'=>$sub->id,'current_page'=>1])); ?>" selected>Price Highest first</option>
            <?php else: ?>
            	<option value="<?php echo e(route('sortBy.priceHighestFirst' ,['id'=>$sub->id,'current_page'=>1])); ?>">Price Highest first</option>
            <?php endif; ?>

            <?php if($sort_type == 'disc'): ?>
              <option value="<?php echo e(route('sortBy.discount' ,['id'=>$sub->id,'current_page'=>1])); ?>" selected>Discount Only</option>
            <?php else: ?>
              <option value="<?php echo e(route('sortBy.discount' ,['id'=>$sub->id,'current_page'=>1])); ?>">Discount Only</option>
            <?php endif; ?>

            <?php if($sort_type == 'brand'): ?>
              <option value="brands" selected>Brand</option>
            <?php else: ?>
              <option value="brands">Brand</option>
            <?php endif; ?>
            </select>



            <?php if($sort_type == 'brand'): ?>
            	<select id="brands" onchange="location = this.value;" style="width: 150px;margin-left: 20px">
            		<?php $__currentLoopData = $sub->brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	              	<?php if($brand_id == $brand->id): ?>
	              		<option value="<?php echo e(route('sortBy.brand' , ['sub_id'=>$sub->id , 'brand_id'=>$brand->id,'current_page'=>1])); ?>" selected><?php echo e($brand->name); ?></option>
	              	<?php else: ?>
	              		<option value="<?php echo e(route('sortBy.brand' , ['sub_id'=>$sub->id , 'brand_id'=>$brand->id,'current_page'=>1])); ?>"><?php echo e($brand->name); ?></option>
	              	<?php endif; ?>
	              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	            </select>
            <?php endif; ?>


            <?php if($sort_type != 'brand'): ?>
            	<select id="brands" onchange="location = this.value;" style="width: 150px;margin-left: 20px;display:none">
            		<option selected disabled>Select Brand</option>
            		<?php $__currentLoopData = $sub->brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	              		<option value="<?php echo e(route('sortBy.brand' , ['sub_id'=>$sub->id , 'brand_id'=>$brand->id,'current_page'=>1])); ?>"><?php echo e($brand->name); ?></option>
	              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	            </select>
            <?php endif; ?>
		</div>
	</form>

		<br class="clr"/>
	<?php endif; ?>	  




<div class="tab-content">
	
	<div class="tab-pane  active" id="blockView">
		<ul class="thumbnails">

		<?php if($products): ?>
			<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<?php $__currentLoopData = $product->colors()->withPivot('id')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					<?php if( $color->pivot->quantity == 0 ): ?>	
						<?php continue ?>
					<?php elseif( $color->pivot->quantity > 0 ): ?>
						<li class="span3">
							
						  <div class="thumbnail">
							<a href="<?php echo e(route('product.color' , ['product_id' => $product->id , 'color_id' =>$color->id])); ?>">
							<img class="product-image" src="<?php echo e(asset($color->photos()->where('product_id',$product->id)->first()->path)); ?>" alt=""/>
							</a>
							<div class="caption">
							  <h5 class="product-name" style="margin-bottom: 30px;"><a  href="<?php echo e(route('product.color' , ['product_id' => $product->id , 'color_id' =>$color->id])); ?>"><?php echo e($product->name); ?></a></h5>



						<!-- if offer price found -->
						<?php if($product->offer_price != 0): ?>								  
						<!-- if offer price found -->
									  	<h4 style="text-align:center"><input type="hidden" class="product-id" value="<?php echo e($product->id); ?>">

									
							
							<?php if($color_product=$color->pivot): ?>
								<?php if( Session::has('cart') && Session::get('cart')->totQty > 0 ): ?>
									<?php if(array_key_exists($color_product->id , Session::get('cart')->items)): ?>
									
										<a style="font-weight:bold"  class="btn btn-danger product-cart" href="<?php echo e(route('product.removeFromCart' ,['product_id'=>$product->id ,'color_id'=>$color->id])); ?>">Remove <i class="icon-shopping-cart"></i>
										   		</a>
									<?php else: ?>
										<a style="font-weight:bold"  class="btn product-cart" href="<?php echo e(route('product.addToCart' ,['product_id'=>$product->id ,'color_id'=>$color->id])); ?>">Add To <i class="icon-shopping-cart"></i>
										   		</a>
									<?php endif; ?>

								<?php else: ?>

										<a style="font-weight:bold"  class="btn product-cart" href="<?php echo e(route('product.addToCart' ,['product_id'=>$product->id ,'color_id'=>$color->id])); ?>">Add To <i class="icon-shopping-cart"></i>
										   		</a>
								<?php endif; ?>
							<?php endif; ?>

							


										   <!-- if offer price found -->
										   	<span class="price"><?php echo e($product->offer_price); ?> EGP</span>
										   <!-- if offer price found -->

										   	</h4>
										   	<span class="discount" style="position:relative;top:-310px;left:-14px;">
												<?php echo e(floor((100-(($product->offer_price/$product->price)*100)) )); ?>% off
											</span>
										   	<p class="before-discount">
													<?php echo e($product->price); ?> EGP
											</p>
						<?php endif; ?>
						<!-- if offer price found -->



						<!-- if No offer price found -->
						<?php if($product->offer_price == 0): ?>
						  
					   		 <h4 style="text-align:center">
						
							<?php if($color_product=$color->pivot): ?>
								<?php if(Session::has('cart') && Session::get('cart')->totQty > 0 ): ?>
									<?php if(array_key_exists($color_product->id , Session::get('cart')->items)): ?>
									
										<a style="font-weight:bold"  class="btn btn-danger product-cart" href="<?php echo e(route('product.removeFromCart' ,['product_id'=>$product->id ,'color_id'=>$color->id])); ?>">Remove <i class="icon-shopping-cart"></i>
										   		</a>
									<?php else: ?>
										<a style="font-weight:bold"  class="btn product-cart" href="<?php echo e(route('product.addToCart' ,['product_id'=>$product->id ,'color_id'=>$color->id])); ?>">Add To <i class="icon-shopping-cart"></i>
										   		</a>
									<?php endif; ?>

								<?php else: ?>

										<a style="font-weight:bold"  class="btn product-cart" href="<?php echo e(route('product.addToCart' ,['product_id'=>$product->id ,'color_id'=>$color->id])); ?>">Add To <i class="icon-shopping-cart"></i>
										   		</a>
								<?php endif; ?>
							<?php endif; ?>

							
								   
						   	<span class="price"><?php echo e($product->price); ?> EGP</span>				
						   	</h4>
						   	<span class="discount" style="position:relative;top:-310px;left:-14px;opacity:0">
								0% off
							</span>
						   	<p class="before-discount" style="opacity:0">
									0 EGP
							</p>
						<?php endif; ?>
						<!-- if No offer price found -->

							   
							</div>
						  </div>
						</li>
						<?php break ?>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		<?php endif; ?>
			
		  </ul>

	<?php if($count > 0): ?>
		  <hr class="soft"/>

		<?php if($page->per_page < $page->totall_items): ?>
		  <!-- Pagination -->
		  <div class="pagination" style="text-align: center;">
		  	<ul>
		  	<!-- sort in sub-category MainPage -->
		  	<?php if($sort_type == null): ?>
		  		<?php if($page->previous): ?>
			  		<li><a href="<?php echo e(route('sub-category.show' , ['id'=>$sub->id , 'current_page'=>($page->current_page-1)])); ?>">Previous</a></li>
			  	<?php else: ?>
			  		<li class="disabled"><a href="#">Previous</a></li>
			  	<?php endif; ?>

				  <?php for($i=1; $i <= $page->totall_pages ; $i++): ?>
				  	<?php if($page->current_page == $i): ?>
				  		<li class="active"><a class="page-link" href="#"><?php echo e($i); ?></a></li>
				  	<?php else: ?>
				  		<li><a class="page-link" href="<?php echo e(route('sub-category.show' , ['id'=>$sub->id , 'current_page'=>$i])); ?>"><?php echo e($i); ?></a></li>
				  	<?php endif; ?>	
				  <?php endfor; ?>

			  	<?php if($page->next): ?>
			  		<li><a href="<?php echo e(route('sub-category.show' , ['id'=>$sub->id , 'current_page'=>($page->current_page+1)])); ?>">Next</a></li>
			  	<?php else: ?>
			  		<li class="disabled"><a href="#">Next</a></li>
			  	<?php endif; ?>
			<?php endif; ?>


			<!-- sort in sub-category disc -->
		  	<?php if($sort_type == 'disc'): ?>
		  		<?php if($page->previous): ?>
			  		<li><a href="<?php echo e(route('sortBy.discount' , ['id'=>$sub->id , 'current_page'=>($page->current_page-1)])); ?>">Previous</a></li>
			  	<?php else: ?>
			  		<li class="disabled"><a href="#">Previous</a></li>
			  	<?php endif; ?>

				  <?php for($i=1; $i <= $page->totall_pages ; $i++): ?>
				  	<?php if($page->current_page == $i): ?>
				  		<li class="active"><a class="page-link" href="#"><?php echo e($i); ?></a></li>
				  	<?php else: ?>
				  		<li><a class="page-link" href="<?php echo e(route('sortBy.discount' , ['id'=>$sub->id , 'current_page'=>$i])); ?>"><?php echo e($i); ?></a></li>
				  	<?php endif; ?>	
				  <?php endfor; ?>

			  	<?php if($page->next): ?>
			  		<li><a href="<?php echo e(route('sortBy.discount' , ['id'=>$sub->id , 'current_page'=>($page->current_page+1)])); ?>">Next</a></li>
			  	<?php else: ?>
			  		<li class="disabled"><a href="#">Next</a></li>
			  	<?php endif; ?>
			<?php endif; ?>


			<!-- sort in sub-category Brand -->
		  	<?php if($sort_type == 'brand'): ?>
		  		<?php if($page->previous): ?>
			  		<li><a href="<?php echo e(route('sortBy.brand' , ['id'=>$sub->id , 'brand_id'=>$brand_id ,'current_page'=>($page->current_page-1)])); ?>">Previous</a></li>
			  	<?php else: ?>
			  		<li class="disabled"><a href="#">Previous</a></li>
			  	<?php endif; ?>

				  <?php for($i=1; $i <= $page->totall_pages ; $i++): ?>
				  	<?php if($page->current_page == $i): ?>
				  		<li class="active"><a class="page-link" href="#"><?php echo e($i); ?></a></li>
				  	<?php else: ?>
				  		<li><a class="page-link" href="<?php echo e(route('sortBy.brand' , ['id'=>$sub->id , 'brand_id'=>$brand_id ,'current_page'=>$i])); ?>"><?php echo e($i); ?></a></li>
				  	<?php endif; ?>	
				  <?php endfor; ?>

			  	<?php if($page->next): ?>
			  		<li><a href="<?php echo e(route('sortBy.brand' , ['id'=>$sub->id , 'brand_id'=>$brand_id ,'current_page'=>($page->current_page+1)])); ?>">Next</a></li>
			  	<?php else: ?>
			  		<li class="disabled"><a href="#">Next</a></li>
			  	<?php endif; ?>
			<?php endif; ?>

			<!-- sort in sub-category Lowest Price -->
		  	<?php if($sort_type == 'low'): ?>
		  		<?php if($page->previous): ?>
			  		<li><a href="<?php echo e(route('sortBy.priceLowestFirst' , ['id'=>$sub->id , 'current_page'=>($page->current_page-1)])); ?>">Previous</a></li>
			  	<?php else: ?>
			  		<li class="disabled"><a href="#">Previous</a></li>
			  	<?php endif; ?>

				  <?php for($i=1; $i <= $page->totall_pages ; $i++): ?>
				  	<?php if($page->current_page == $i): ?>
				  		<li class="active"><a class="page-link" href="#"><?php echo e($i); ?></a></li>
				  	<?php else: ?>
				  		<li><a class="page-link" href="<?php echo e(route('sortBy.priceLowestFirst' , ['id'=>$sub->id , 'current_page'=>$i])); ?>"><?php echo e($i); ?></a></li>
				  	<?php endif; ?>	
				  <?php endfor; ?>

			  	<?php if($page->next): ?>
			  		<li><a href="<?php echo e(route('sortBy.priceLowestFirst' , ['id'=>$sub->id , 'current_page'=>($page->current_page+1)])); ?>">Next</a></li>
			  	<?php else: ?>
			  		<li class="disabled"><a href="#">Next</a></li>
			  	<?php endif; ?>
			<?php endif; ?>


			<!-- sort in sub-category Highest Price -->
			<?php if($sort_type == 'high'): ?>
		  		<?php if($page->previous): ?>
			  		<li><a href="<?php echo e(route('sortBy.priceHighestFirst' , ['id'=>$sub->id , 'current_page'=>($page->current_page-1)])); ?>">Previous</a></li>
			  	<?php else: ?>
			  		<li class="disabled"><a href="#">Previous</a></li>
			  	<?php endif; ?>

				  <?php for($i=1; $i <= $page->totall_pages ; $i++): ?>
				  	<?php if($page->current_page == $i): ?>
				  		<li class="active"><a class="page-link" href="#"><?php echo e($i); ?></a></li>
				  	<?php else: ?>
				  		<li><a class="page-link" href="<?php echo e(route('sortBy.priceHighestFirst' , ['id'=>$sub->id , 'current_page'=>$i])); ?>"><?php echo e($i); ?></a></li>
				  	<?php endif; ?>	
				  <?php endfor; ?>

			  	<?php if($page->next): ?>
			  		<li><a href="<?php echo e(route('sortBy.priceHighestFirst' , ['id'=>$sub->id , 'current_page'=>($page->current_page+1)])); ?>">Next</a></li>
			  	<?php else: ?>
			  		<li class="disabled"><a href="#">Next</a></li>
			  	<?php endif; ?>
			<?php endif; ?>

			</ul>
			</div>
		<?php endif; ?>

	<?php endif; ?>
		  

		<br class="clr"/>
	</div>
</div>

	
	


<br class="clr"/>


</div>

<?php $__env->stopSection(); ?>





<?php $__env->startSection('scripts'); ?>
		
		<script type="text/javascript">
	
				

				$(document).ready(function(){
				
					$('#sortBy').on('change' , function(){
						if( $(this).val() == 'brands'){
							
							$('#brands').show();
							window.stop();
						}
					});					

				});

			

		</script>

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>