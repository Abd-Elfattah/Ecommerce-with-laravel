<?php $__env->startSection('content'); ?>

	<!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header col-lg-6 col-lg-offset-3" style="padding-left:0">
                            Edit User
                            
                        </h1>
                        <div class="row">
                            <div class="col-lg-6 col-lg-offset-3">
                                <?php if(Session::has('editUser')): ?>
                                    <ol class="breadcrumb">
                                        <li class="active">
                                            <i class="fa fa-user"></i> 
                                            <span class="text-success text-center"><?php echo e(session('editUser')); ?></span>
                                        </li>
                                    </ol>

                                <?php endif; ?>
                            </div>
                        </div>


                    </div>
                </div>
    <!-- /.row -->


    <div class="row">
        <div class="col-lg-6 col-lg-offset-3">
            <?php echo Form::model( $user , ['method'=>'PATCH' , 'action'=>['AdminUsersController@update' , $user->id]]); ?>


                <div class="form-group">
                    <?php echo Form::label('firstname','First Name :'); ?>

                    <?php echo Form::text('firstname' , null , ['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('lastname','Last Name :'); ?>

                    <?php echo Form::text('lastname' , null , ['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('email','E-mail :'); ?>

                    <?php echo Form::email('email' , null , ['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('password','Password :'); ?>

                    <?php echo Form::password('password' , ['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('is_admin','Role :'); ?>

                    <?php echo Form::select('is_admin' , array(1 => 'Adminstrator' , 0 => 'Client'), null , ['class'=>'form-control']); ?>

                </div>

                <div class="form-group pull-left">
                
                    <?php echo Form::submit('Edit User' , ['class' => 'btn btn-primary']); ?>

                </div>

            <?php echo Form::close(); ?>



            <!-- DELETE FORM -->
            <?php echo Form::model($user , ['method'=>'DELETE' , 'action'=>['AdminUsersController@destroy' , $user->id]]); ?>

                <div class="form-group">
                    <?php echo Form::submit('Delete User' , ['class' => 'btn btn-danger' , 'style'=>'margin-left:10px']); ?>

                </div>
            <?php echo Form::close(); ?>

            <!-- DELETE FORM -->
        </div>
    </div>

            
            
    </div>

    


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>