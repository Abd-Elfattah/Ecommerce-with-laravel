<?php $__env->startSection('content'); ?>

	<div class="span9">
    <ul class="breadcrumb">
		<li><a href="<?php echo e(asset('Eco-home')); ?>">Home</a> <span class="divider">/</span></li>
		<li class="active"> Shopping Cart</li>
    </ul>
	<h3>Shopping Cart<a href="<?php echo e(route('homePage')); ?>" class="btn btn-large pull-right"><i class="icon-arrow-left"></i> Continue Shopping </a></h3>	
	<hr class="soft"/>
	
<?php if(Session::has('cart')): ?>		
	<?php if( $cart->totQty > 0): ?>
	<table class="table table-bordered" style="margin-bottom: 40px">
              <thead>
                <tr>
                  <th>Product</th>
                  <th>Description</th>
                  <th>Quantity</th>
				  <th>Price (EGP)</th>
                  <th>Discount (EGP)</th>                  
                  <th>After Discount (EGP)</th>
                  <th>Remove</th>
				</tr>
              </thead>
              <tbody>

     	<?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
     		
                <tr>
                  <td> <a href="<?php echo e(route('product.color',['product_id'=>$product['product_id'] , 'color_id'=>$product['color_id']])); ?>"><img width="60" src="<?php echo e(asset(App\Photo::where(['product_id'=>$product['product_id'] ,'color_id'=>$product['color_id']])->first()->path)); ?>" alt=""/></a></td>
                  <td><?php echo e(App\Product::find($product['product_id'])->name); ?><br/>Color : <?php echo e(App\Color::find($product['color_id'])->name); ?><br> Brand : <?php echo e(App\Product::find($product['product_id'])->brand->name); ?></td>

                  <td>
                  	<?php if(($quantity=App\Product::find($product['product_id'])->colors()->where('color_id',$product['color_id'])->first()->pivot->quantity) > 0 ): ?>
                  	<select class="form-control" style="width:60px" onchange="location = this.value;">
                  		<!-- <option selected disabled>Qty</option> -->
                  		<?php if($product['quantity'] == 1): ?>
                  		<option value="<?php echo e(route('product.changeQuantity' , ['product_id' => $product['product_id'] , 'color_id' => $product['color_id'] , 'count'=>1 ])); ?>" selected>1</option>
                  		<?php elseif($product['quantity'] != 1): ?>
                  		<option value="<?php echo e(route('product.changeQuantity' , ['product_id' => $product['product_id'] , 'color_id' => $product['color_id'] , 'count'=>1 ])); ?>">1</option>
                  		<?php endif; ?>

                  		<?php if($product['quantity'] == 2 && $quantity >=2): ?>
                  		<option value="<?php echo e(route('product.changeQuantity' , ['product_id' => $product['product_id'] , 'color_id' => $product['color_id'] , 'count'=>2 ])); ?>" selected>2</option>
                  		<?php elseif($product['quantity'] != 2 &&  $quantity >= 2): ?>
                  		<option value="<?php echo e(route('product.changeQuantity' , ['product_id' => $product['product_id'] , 'color_id' => $product['color_id'] , 'count'=>2 ])); ?>">2</option>
                  		<?php endif; ?>


                  		<?php if($product['quantity'] == 3 &&  $quantity >= 3): ?>
                  		<option value="<?php echo e(route('product.changeQuantity' , ['product_id' => $product['product_id'] , 'color_id' => $product['color_id'] , 'count'=>3 ])); ?>" selected>3</option>
                  		<?php elseif($product['quantity'] != 3 && $quantity >= 3): ?>
                  		<option value="<?php echo e(route('product.changeQuantity' , ['product_id' => $product['product_id'] , 'color_id' => $product['color_id'] , 'count'=>3 ])); ?>">3</option>
                  		<?php endif; ?>

                  		<?php if($product['quantity'] == 4 &&  $quantity >= 4): ?>
                  		<option value="<?php echo e(route('product.changeQuantity' , ['product_id' => $product['product_id'] , 'color_id' => $product['color_id'] , 'count'=>4 ])); ?>" selected>4</option>
                  		<?php elseif($product['quantity'] != 4 && $quantity >= 4): ?>
                  		<option value="<?php echo e(route('product.changeQuantity' , ['product_id' => $product['product_id'] , 'color_id' => $product['color_id'] , 'count'=>4 ])); ?>">4</option>
                  		<?php endif; ?>


                  		<?php if($product['quantity'] == 5 &&  $quantity >= 5): ?>
                  		<option value="<?php echo e(route('product.changeQuantity' , ['product_id' => $product['product_id'] , 'color_id' => $product['color_id'] , 'count'=>5 ])); ?>" selected>5</option>
                  		<?php elseif($product['quantity'] != 5 && $quantity >= 5): ?>
                  		<option value="<?php echo e(route('product.changeQuantity' , ['product_id' => $product['product_id'] , 'color_id' => $product['color_id'] , 'count'=>5 ])); ?>">5</option>
                  		<?php endif; ?>
                  	</select>


                  	<?php if( $quantity <= 5): ?>
                  		<p style="color:#b94a48">only <?php echo e($quantity); ?> Remind</p>
                  	<?php endif; ?>

	                <?php elseif( $quantity == 0 ): ?>
	                	<p style="color:#b94a48;margin-top: 18px;margin-left: 10px">Out of Stock</p>
	                <?php endif; ?>	

                  </td>



                  <td>
                  	<?php if($quantity > 0): ?>
	                  	<?php if($product['quantity'] > 1 && $quantity > 1): ?>
	                  		<?php echo e(($product['price']+$product['discount'])*$product['quantity']); ?> <br>
	                  		<?php echo e(" ( ". ($product['price']+$product['discount']) ." For 1 )"); ?>


	                  	<?php else: ?>
	                  		<?php echo e(($product['price']+$product['discount'])); ?>

	                  	<?php endif; ?>
	                <?php else: ?>
	                	<p style="color:#b94a48;margin-top: 18px;margin-left: 10px"> - - - - - - - - -</p>
	                <?php endif; ?>
                  </td>
                  <td>
                  	<?php if($quantity > 0): ?>
	                  	<?php if($product['discount'] == 0): ?>
	                  		0

	                  	<?php elseif($product['quantity'] > 1 && $quantity > 1): ?>
	                  		<?php echo e(($product['discount']*$product['quantity'])); ?> <br>
	                  		<?php echo e(" ( ". ($product['discount']) ." For 1 )"); ?>

	                  	<?php else: ?>
	                  		<?php echo e(($product['discount'])); ?>

	                  	<?php endif; ?>
	                <?php else: ?>
	                	<p style="color:#b94a48;margin-top: 18px;margin-left: 10px"> - - - - - - - - - </p>
	                <?php endif; ?>
                  </td>
                  <td>
                  	<?php if($quantity > 0): ?>
	                  	<?php if($product['quantity'] > 1 && $quantity > 1): ?>
	                  		<?php echo e(($product['price']*$product['quantity'])); ?> <br>
	                  		<?php echo e(" ( ". ($product['price']) ." For 1 )"); ?>

	                  	<?php else: ?>
	                  		<?php echo e(($product['price'])); ?>

	                  	<?php endif; ?>
	                <?php else: ?>
	                	<p style="color:#b94a48;margin-top: 18px;margin-left: 10px"> - - - - - - - - - </p>
	                <?php endif; ?>
                  </td>
                  <td><a class="btn btn-danger" href="<?php echo e(route('product.removeFromCart' , ['product_id' => $product['product_id'] , 'color_id' => $product['color_id'] ] )); ?>" type="button"><i class="icon-remove icon-white"></i></a> </td>
                </tr>
				
				
                
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

		</tbody>
	</table>


	<table class="table table-bordered pull-left" style="width:40%;margin-right: 35px" >
		<tbody>
			<tr>
		      <td style="text-align:left">Total Price	</td>
		      <td style="width:40%"><?php echo e(number_format($cart->totPrice+$cart->totDisc ,2)); ?></td>
		    </tr>
			 <tr>
		      <td style="text-align:left">Total Discount	</td>
		      <td style="width:40%"><?php echo e(number_format($cart->totDisc,2)); ?></td>
		    </tr>
		     
		      
			 <tr>
		      <td style="text-align:left"><strong>TOTAL (EGP) </strong></td>
		      <td class="label label-important" style="display:block"> <strong> <?php echo e(number_format($cart->totPrice,2)); ?> </strong></td>
		    </tr>
		</tbody>
	</table>
	
            
		
			
			
		
			<?php echo Form::open(['method'=>'POST' , 'action'=>'CartController@checkOut' , 'class'=>'pull-left']); ?>

			<div class="form-group">
				<?php if(Auth::user()->addresses->count() > 0): ?>
				<p style="font-size: 18px;font-weight: bold">Select Address</p>
				<?php $__currentLoopData = Auth::user()->addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					<p style="font-size: 15px;font-weight: bold">
						<input type="radio" name="address_id" value="<?php echo e($address->id); ?>">
						<span><?php echo e($address->city); ?></span>
						<span>, <?php echo e($address->area); ?></span>
						<p style="margin-left:20px;margin-top: -10px;font-weight: bold"><?php echo e($address->mobile); ?></p>
					</p>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				<?php endif; ?>
				<button class="btn btn-large btn-success pull-left">Checkout <i class="icon-arrow-right"></i></button>

			</div>
			<?php echo Form::close(); ?>

		
	<?php else: ?> 
		<h2>Cart is Empty</h2>
	<?php endif; ?>	
	
<?php else: ?> 
	<h2>Cart is Empty</h2>
<?php endif; ?>

</div>

	




<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>