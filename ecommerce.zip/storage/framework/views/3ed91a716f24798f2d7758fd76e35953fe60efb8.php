<?php $__env->startSection('content'); ?>

	<!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header col-lg-6 col-lg-offset-3" style="padding-left:0">
                            Edit Brand
                            
                        </h1>


                        <div class="row">
                            <div class="col-lg-6 col-lg-offset-3">
                                <?php if(Session::has('editBrand')): ?>
                                    <ol class="breadcrumb">
                                        <li class="active">
                                            <i class="fa fa-user"></i> 
                                            <span class="text-success text-center"><?php echo e(session('editBrand')); ?></span>
                                        </li>
                                    </ol>

                                <?php endif; ?>
                            </div>
                        </div>
                        


                    </div>
                </div>
    <!-- /.row -->


    <div class="row">
        <div class="col-lg-6 col-lg-offset-3">
            <?php echo Form::model($brand , ['method'=>'PATCH' , 'action'=>['BrandController@update', $brand->id] ]); ?>



                <div class="form-group category">
                    <label for="category_id">Category</label>

                    <select id="category_id" class="form-control cat">
                        

                       
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <?php if($brand->subcategory->category->id == $cat->id): ?>
                                    <option value="<?php echo e($cat->id); ?>" selected><?php echo e($cat->name); ?></option>

                                <?php else: ?>
                                    <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                                <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                       
                    </select>


                </div>

                <div class="form-group">
                    <label for="subcategory_id">Sub-Category</label>
                    <select name="subcategory_id" id="subcategory_id" class="form-control subCat">
                        <?php $__currentLoopData = $subs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <?php if($brand->subcategory->id == $sub->id): ?>
                                <option value="<?php echo e($sub->id); ?>" selected><?php echo e($sub->name); ?></option>

                            <?php else: ?>
                                <option value="<?php echo e($sub->id); ?>"><?php echo e($sub->name); ?></option>
                            <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </select>
                </div>


                <div class="form-group">
                    <?php echo Form::label('name','Brand :'); ?>

                    <?php echo Form::text('name' , null , ['class'=>'form-control']); ?>

                </div>

                

                
                <div class="form-group">
                    <?php echo Form::submit('Edit Brand' , ['class' => 'btn btn-primary']); ?>

                </div>
            <?php echo Form::close(); ?>

        </div>
    </div>





<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
        <script type="text/javascript">

                // Multi select with ajax


                
                $(document).ready(function(){

                    $('.cat').on('change',function(){

                        var cat_id = $(this).val();

                        option = " ";
                        var div = $(this).parent().parent();

                        $.ajax({
                            type:'get',
                            url:'<?php echo URL::to('ajaxSub'); ?>',
                            data:{'id':cat_id},
                            success:function(data){
                                
                                for(var i=0; i<data.length;i++){
                                    option+= '<option value="'+data[i].id+'">'+data[i].name+'</option>';

                                    div.find('.subCat').html(" ");
                                    div.find('.subCat').append(option);
                                }

                            },
                            error:function(){

                            }
                        });                        

                    });

                });

        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>