<?php $__env->startSection('content'); ?>

	<!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header col-lg-6 col-lg-offset-3" style="padding-left:0">
                            Edit Sub-Categories
                            
                        </h1>

                        <div class="row">
                            <div class="col-lg-6 col-lg-offset-3">
                                <?php if(Session::has('editSub')): ?>
                                    <ol class="breadcrumb">
                                        <li class="active">
                                            <i class="fa fa-user"></i> 
                                            <span class="text-success text-center"><?php echo e(session('editSub')); ?></span>
                                        </li>
                                    </ol>

                                <?php endif; ?>
                            </div>
                        </div>

                    </div>
                </div>
    <!-- /.row -->


    <div class="row">
        <div class="col-lg-6 col-lg-offset-3">
            <?php echo Form::model($sub , ['method'=>'PATCH' , 'action'=>['SubCategoryController@update' , $sub->id] ]); ?>



                <div class="form-group">
                    <?php echo Form::label('category_id','Category :'); ?>

                    <?php echo Form::select('category_id' , $categories , null , ['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('name','Name :'); ?>

                    <?php echo Form::text('name' , null , ['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('attr1','Attribute 1 :'); ?>

                    <?php echo Form::text('attr1' , null , ['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('attr2','Attribute 2 :'); ?>

                    <?php echo Form::text('attr2' , null , ['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('attr3','Attribute 3 :'); ?>

                    <?php echo Form::text('attr3' , null , ['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('attr4','Attribute 4 :'); ?>

                    <?php echo Form::text('attr4' , null , ['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('attr5','Attribute 5 :'); ?>

                    <?php echo Form::text('attr5' , null , ['class'=>'form-control']); ?>

                </div>

                
                <div class="form-group">
                    <?php echo Form::submit('Edit Sub-Category' , ['class' => 'btn btn-primary']); ?>

                </div>
            <?php echo Form::close(); ?>


            <!-- DELETE FORM -->
            <?php echo Form::model($sub , ['method'=>'DELETE' , 'action'=>['SubCategoryController@destroy' , $sub->id]]); ?>

                <div class="form-group">
                    <?php echo Form::submit('Delete Sub-Category' , ['class' => 'btn btn-danger']); ?>

                </div>
            <?php echo Form::close(); ?>

            <!-- DELETE FORM -->


        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>