<?php $__env->startSection('styles'); ?>
<style type="text/css">
		.before-discount{
			
			margin-top: -85px;
			margin-left:110px;
			height: 55px;
		}

		.tag{
			background:none;
		}
		.discount_offers{
			background-color:#da4f49;
			height:auto;
			width:55px;
			color:white;
			padding: 6px 10px;
			font-size:15px;
			margin-right: 10px;
			font-weight: bold;
			opacity:0.88;
			right: -10px;
		}

		.price{
			color:#006dcc;
			margin-left:8px;
			font-size:19px;
		}

		.before-Discount{
			text-decoration: line-through;
			color: #b8b894;
			font-size:16px;
			position: relative;
			left:-10px;
			top:-20px;
			float: right;

		}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="span9">	

<div class="well well-small" style="height: 330px">
<h4><a href="<?php echo e(route('offers')); ?>">Best Offers</a> <small class="pull-right"><?php echo e(count($offer_products) . " Offers Available"); ?></small></h4>
<div class="row-fluid">
	<div id="featured" class="carousel slide" >
		<div class="carousel-inner" >


			<div class="item active">
			  <ul class="thumbnails">
			  	<?php $offers = array_slice($offer_products, 0 , 4) ?>
			  <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<?php $__currentLoopData = $product->colors()->withPivot('id')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					<?php if( $color->pivot->quantity == 0 ): ?>	
						<?php continue ?>
					<?php elseif( $color->pivot->quantity > 0 ): ?>


						<li class="span3">
						  <div class="thumbnail">
						  	<span class="tag discount_offers">
								<?php echo e(floor((100-(($product->offer_price/$product->price)*100)) )); ?>% off
							</span>
							<a href="<?php echo e(route('product.color' , ['product_id' => $product->id , 'color_id' =>$color->id])); ?>">
								<img height="160px" src="<?php echo e(asset($product->photos()->where('color_id', $color->id)->first()->path )); ?>" alt=""></a>
							<div class="caption">
							  <h5><a style="color:#555" href="<?php echo e(route('product.color' , ['product_id' => $product->id , 'color_id' =>$color->id])); ?>"><?php echo e($product->name); ?></a></h5>
							   <h4><a class="btn" href="<?php echo e(route('product.color' , ['product_id' => $product->id , 'color_id' =>$color->id])); ?>">VIEW</a> 
							   	<span class="price pull-right"><?php echo e($product->offer_price); ?> EGP</span>
							   	<p class="before-Discount"><?php echo e($product->price); ?> EGP</p>
							   </h4>
							</div>
						  </div>
						</li>


						<?php break; ?>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			  </ul>
			</div>


			<?php if(count($offer_products) > 4): ?>
			<?php $offers = array_slice($offer_products, 4) ?>
			<div class="item">
			  <ul class="thumbnails">
			  <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<?php $__currentLoopData = $product->colors()->withPivot('id')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					<?php if( $color->pivot->quantity == 0 ): ?>	
						<?php continue ?>
					<?php elseif( $color->pivot->quantity > 0 ): ?>


						<li class="span3">
						  <div class="thumbnail">
						  	<span class="tag discount_offers">
								<?php echo e(floor((100-(($product->offer_price/$product->price)*100)) )); ?>% off
							</span>
							<a href="<?php echo e(route('product.color' , ['product_id' => $product->id , 'color_id' =>$color->id])); ?>">
								<img height="160px" src="<?php echo e(asset($product->photos()->where('color_id', $color->id)->first()->path )); ?>" alt=""></a>
							<div class="caption">
							  <h5><a style="color:#555" href="<?php echo e(route('product.color' , ['product_id' => $product->id , 'color_id' =>$color->id])); ?>"><?php echo e($product->name); ?></a></h5>
							   <h4><a class="btn" href="<?php echo e(route('product.color' , ['product_id' => $product->id , 'color_id' =>$color->id])); ?>">VIEW</a> 
							   	<span class="price pull-right"><?php echo e($product->offer_price); ?> EGP</span>
							   	<p class="before-Discount"><?php echo e($product->price); ?> EGP</p>
							   </h4>
							</div>
						  </div>
						</li>


						<?php break; ?>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

			  </ul>
			</div>

			<?php endif; ?>

		</div>

		
		  <a class="left carousel-control" href="#featured" data-slide="prev">‹</a>
		  <a class="right carousel-control" href="#featured" data-slide="next">›</a>
			
	</div>
  </div>
</div>



<h3>Latest Products </h3>
	  <ul class="thumbnails">
			<?php if($latest_products): ?>
			<?php $__currentLoopData = $latest_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<?php $__currentLoopData = $product->colors()->withPivot('id')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					<?php if( $color->pivot->quantity == 0 ): ?>	
						<?php continue ?>
					<?php elseif( $color->pivot->quantity > 0 ): ?>
						<li class="span3">
							
						  <div class="thumbnail">
							<a href="<?php echo e(route('product.color' , ['product_id' => $product->id , 'color_id' =>$color->id])); ?>">
							<img class="product-image" src="<?php echo e(asset($color->photos()->where('product_id',$product->id)->first()->path)); ?>" alt=""/>
							</a>
							<div class="caption">
							  <h5 class="product-name" style="margin-bottom: 30px;"><a  href="<?php echo e(route('product.color' , ['product_id' => $product->id , 'color_id' =>$color->id])); ?>"><?php echo e($product->name); ?></a></h5>

						<!-- if No offer price found -->
						<?php if($product->offer_price == 0): ?>
						  
					   		 <h4 style="text-align:center">
						
							<?php if($color_product=$color->pivot): ?>
								<?php if(Session::has('cart') && Session::get('cart')->totQty > 0 ): ?>
									<?php if(array_key_exists($color_product->id , Session::get('cart')->items)): ?>
									
										<a style="font-weight:bold"  class="btn btn-danger product-cart" href="<?php echo e(route('product.removeFromCart' ,['product_id'=>$product->id ,'color_id'=>$color->id])); ?>">Remove <i class="icon-shopping-cart"></i>
										   		</a>
									<?php else: ?>
										<a style="font-weight:bold"  class="btn product-cart" href="<?php echo e(route('product.addToCart' ,['product_id'=>$product->id ,'color_id'=>$color->id])); ?>">Add To <i class="icon-shopping-cart"></i>
										   		</a>
									<?php endif; ?>

								<?php else: ?>

										<a style="font-weight:bold"  class="btn product-cart" href="<?php echo e(route('product.addToCart' ,['product_id'=>$product->id ,'color_id'=>$color->id])); ?>">Add To <i class="icon-shopping-cart"></i>
										   		</a>
								<?php endif; ?>
							<?php endif; ?>

							
						   	<span class="price"><?php echo e($product->price); ?> EGP</span>				
						   	</h4>
						   	<span class="discount" style="position:relative;top:-310px;left:-14px;opacity:0">
								0% off
							</span>
						   	<p class="before-discount" style="opacity:0">
									0 EGP
							</p>
						<?php endif; ?>
						<!-- if No offer price found -->

							   
							</div>
						  </div>
						</li>
						<?php break ?>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		<?php endif; ?>
			
		  </ul>

</div>



<?php $__env->stopSection(); ?>





<?php $__env->startSection('scripts'); ?>
		

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>