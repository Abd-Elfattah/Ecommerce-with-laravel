<?php $__env->startSection('content'); ?>

	<!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header col-lg-6 col-lg-offset-3" style="padding-left:0">
                            Create Brand
                            
                        </h1>
                        


                    </div>
                </div>
    <!-- /.row -->


    <div class="row">
        <div class="col-lg-6 col-lg-offset-3">
            <?php echo Form::open(['method'=>'POST' , 'action'=>'BrandController@store']); ?>



                <div class="form-group category">
                    <label for="category_id">Category</label>

                    <select id="category_id" class="form-control cat">
                        <option selected disabled>Choose Category</option>

                        <?php if($categories): ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        <?php endif; ?>
                    </select>


                </div>

                <div class="form-group">
                    <label for="subcategory_id">Sub-Category</label>
                    <select name="subcategory_id" id="subcategory_id" class="form-control subCat">
                        <option selected disabled>Select Sub-Category</option>
                    </select>
                </div>


                <div class="form-group">
                    <?php echo Form::label('name','Brand :'); ?>

                    <?php echo Form::text('name' , null , ['class'=>'form-control']); ?>

                </div>

                

                
                <div class="form-group">
                    <?php echo Form::submit('Create Brand' , ['class' => 'btn btn-primary']); ?>

                </div>
            <?php echo Form::close(); ?>

        </div>
    </div>





<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
        <script type="text/javascript">

                // Multi select with ajax


                
                $(document).ready(function(){

                    $('.cat').on('change',function(){

                        var cat_id = $(this).val();

                        option = " ";
                        var div = $(this).parent().parent();

                        $.ajax({
                            type:'get',
                            url:'<?php echo URL::to('ajaxSub'); ?>',
                            data:{'id':cat_id},
                            success:function(data){
                                
                                for(var i=0; i<data.length;i++){
                                    option+= '<option value="'+data[i].id+'">'+data[i].name+'</option>';

                                    div.find('.subCat').html(" ");
                                    div.find('.subCat').append(option);
                                }

                            },
                            error:function(){

                            }
                        });                        

                    });

                });

        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>