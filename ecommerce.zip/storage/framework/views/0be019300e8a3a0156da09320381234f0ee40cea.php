<?php $__env->startSection('content'); ?>

	<!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header col-lg-12" style="padding-left:0">
                       		<?php echo e($product->name . " - " . $color->name . " color"); ?>


                            <a href="<?php echo e(route('color.add.images' , [$product->id , $color->id])); ?>" class="btn btn-primary" style="margin-left:40px">Add Images</a>
                        </h1>
                        
                    </div>
                </div>
    <!-- /.row -->



    <div class="row">
        <div class="col-lg-12">
            <table class="table">
                <thead>
                  <tr>
                    
                    <th>Photo</th>
                    <th>Product</th>
                    <th>Color</th>
                    <th>Delete</th>                    
                  </tr>
                </thead>
                <tbody>
                	<?php if($photos): ?>
	                    <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	                      <tr>
	                        
	                        <td><img width="70px" src="<?php echo e(asset($photo->path)); ?>"></td>
	                        <td><?php echo e($product->name); ?></td>
	                        <td><?php echo e($color->name); ?></td>
	                        <td><a href="<?php echo e(route('color.images.delete' , $photo->id)); ?>">Delete</a></td>
	                      </tr>
	                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>



    <!-- Pagination -->
        
    <div class="row text-center">
        
    </div>


    


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>