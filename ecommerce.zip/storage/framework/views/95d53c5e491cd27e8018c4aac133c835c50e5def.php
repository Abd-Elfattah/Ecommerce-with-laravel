<?php $__env->startSection('content'); ?>

    <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header col-lg-12" style="padding-left:0">
                             Categories

                        </h1>
                        
                    </div>
                </div>
    <!-- /.row -->


    <!-- row -->

        <!-- <div class="row"> -->
                    <div class="col-lg-4 col-lg-offset-1">

                        <?php if(Session::has('emptyCategory')): ?>
                                <ol class="breadcrumb">
                                    <li class="active">
                                        <i class="fa fa-user"></i> 
                                        <span class="text-danger"><?php echo e(session('emptyCategory')); ?></span>
                                    </li>
                                </ol>

                        <?php endif; ?>

                        <h2>Edit Category</h2>

                            <?php echo Form::model($category ,[ 'method'=>'PATCH' , 'action'=>['CategoryController@update' , $category->id]]); ?>


                                <div class="form-group">
                                    <?php echo Form::label('name','Name :'); ?>

                                    <?php echo Form::text('name' , null , ['class'=>'form-control']); ?>

                                </div>
                                
                                <div class="form-group">
                                    <?php echo Form::submit('Edit Category' , ['class' => 'btn btn-primary']); ?>

                                </div>
                            <?php echo Form::close(); ?>

                    </div>
        <!-- </div> -->

    <!-- row -->




    <!-- row -->
        <!-- <div class="row"> -->

                <!-- pagination -->


            </div>
        <!-- </div> -->
    <!-- row -->


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>