<?php $__env->startSection('content'); ?>

    <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header col-lg-12" style="padding-left:0">
                             <?php echo e($product->name . " Colors"); ?>


                        </h1>
                        
                    </div>
                </div>
    <!-- /.row -->


    <!-- row -->

        <!-- <div class="row"> -->
                    <div class="col-lg-4 col-lg-offset-1">

                        

                        <h2>Create Color</h2>

                            <?php echo Form::open(['method'=>'POST' , 'action'=>['ColorController@storeColor' , $product->id ]]); ?>


                                <div class="form-group">
                                    <label for="color">Color</label>
                                    <select id="color" name="color_id" class="form-control">
                                        
                                            <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                
                                        
                                                    <option value="<?php echo e($color->id); ?>"><?php echo e($color->name); ?></option>
                                                
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                       
                                    </select>
                                </div>


                                <div class="form-group">
                                    <?php echo Form::label('quantity','Quantity'); ?>

                                    <?php echo Form::text('quantity' , null , ['class'=>'form-control']); ?>

                                </div>
                                
                                <div class="form-group">
                                    <?php echo Form::submit('Create Color' , ['class' => 'btn btn-primary']); ?>

                                </div>
                            <?php echo Form::close(); ?>


                    </div>
        <!-- </div> -->

    <!-- row -->




    <!-- row -->
        <!-- <div class="row"> -->
            <div class="col-lg-6 col-lg-offset-1" style="margin-top:85px; border-left:1px solid #DDDDDD; padding-left:40px">

                <?php if(Session::has('deleteCategory')): ?>
                    <ol class="breadcrumb" style="clear:both">
                        <li class="active">
                            <i class="fa fa-user"></i> 
                            <span class="text-danger"><?php echo e(session('deleteCategory')); ?></span>
                        </li>
                    </ol>

                <?php endif; ?>


                <?php if(Session::has('createCategory')): ?>
                        <ol class="breadcrumb">
                            <li class="active">
                                <i class="fa fa-user"></i> 
                                <span class="text-success"><?php echo e(session('createCategory')); ?></span>
                            </li>
                        </ol>

                <?php endif; ?>


                <?php if(Session::has('editCategory')): ?>
                        <ol class="breadcrumb">
                            <li class="active">
                                <i class="fa fa-user"></i> 
                                <span class="text-success"><?php echo e(session('editCategory')); ?></span>
                            </li>
                        </ol>

                <?php endif; ?>


                <table class="table">
                    <thead>
                      <tr>
                        
                        
                        <th>Color</th>
                        <th>Quantiy</th>
                        <th>Created At</th>
                        <th>Updated At</th>
                        <th>Edit</th>
                        <th>Delete</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php if($product->colors): ?>
                        <?php $__currentLoopData = $product->colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                          <tr> 
                            <td><?php echo e($color->name); ?></td>
                            <td><?php echo e($color->pivot->quantity); ?></td>
                            <td><?php echo e($color->pivot->created_at->diffForHumans()); ?></td>
                            <td><?php echo e($color->pivot->updated_at->diffForHumans()); ?></td>
                            <td><a href="">Edit</a></td>
                            <td><a href="">Delete</a></td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <?php endif; ?>
                    </tbody>
                </table>


               


            </div>
        <!-- </div> -->
    <!-- row -->


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>