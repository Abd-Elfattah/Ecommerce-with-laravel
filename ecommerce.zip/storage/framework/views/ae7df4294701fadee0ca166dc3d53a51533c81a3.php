<?php $__env->startSection('content'); ?>

	<!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header col-lg-12" style="padding-left:0">
                             Sub-Categories


                            <a href="<?php echo e(route('sub.create')); ?>" class="btn btn-info" style=" margin-left:25px">Create Sub-category</a>
                        </h1>

                        


                        <?php if(Session::has('createSub')): ?>
                            <ol class="breadcrumb" style="clear:both">
                                <li class="active">
                                    <i class="fa fa-user"></i> 
                                    <span class="text-success"><?php echo e(session('createSub')); ?></span>
                                </li>
                            </ol>

                        <?php endif; ?>



                        <?php if(Session::has('deleteSub')): ?>
                            <ol class="breadcrumb" style="clear:both">
                                <li class="active">
                                    <i class="fa fa-user"></i> 
                                    <span class="text-danger"><?php echo e(session('deleteSub')); ?></span>
                                </li>
                            </ol>

                        <?php endif; ?>
                        
                    </div>
                </div>
    <!-- /.row -->



    <div class="row">
        <div class="col-lg-12">
            <table class="table">
                <thead>
                  <tr>
                    
                    <th>ID</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Brands</th>
                    <th>Created At</th>
                    <th>Updated At</th>
                    <th>Edit</th>
                  </tr>
                </thead>
                <tbody>
                <?php if($subs): ?>
                    <?php $__currentLoopData = $subs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                      <tr>
                        <td><?php echo e($sub->id); ?></td>
                        <td><?php echo e($sub->name); ?></td>
                        <td><?php echo e($sub->category->name); ?></td>
                        <td><a href="<?php echo e(route('sub.brands' , $sub->id)); ?>">View</a></td>
                        <td><?php echo e($sub->created_at->diffForHumans()); ?></td>
                        <td><?php echo e($sub->updated_at->diffForHumans()); ?></td>
                        <td><a href="<?php echo e(route('sub.edit' , $sub->id)); ?>">Edit</a></td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>



    <!-- Pagination -->

    <?php if($subs): ?>
        <div class="row text-center">
            <?php echo e($subs->render()); ?>

        </div>
    <?php endif; ?>


    


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>