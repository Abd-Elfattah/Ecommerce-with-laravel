<?php $__env->startSection('styles'); ?>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.2.0/min/dropzone.min.css">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>


<h1 class="text-center">Add Images For <?php echo e(" " . $color->name . " "); ?> Color</h1>	
<h3 class="text-center">Add Photos</h3>
	

  <?php echo Form::open(['method'=>'POST' , 'action'=>['ColorController@storeNewColorImages' , $product->id , $color->id] , 'class'=>'dropzone' , 'files'=>true ]); ?>

  
	<?php echo Form::close(); ?>


	<div class="text-center">
		<a class="btn btn-primary" href="<?php echo e(route('color.images' , [$product->id , $color->id])); ?>">Add Images</a>
	</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.2.0/min/dropzone.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>